public class WhileLoopChallenge {

    public static void main(String[] args) {

//        isEvenNumber(0);
//
//        System.out.println();

        int number = 4;
        int finishNumber = 20;
        int evencount = 0;
        int oddcount = 0;


     while (number <= finishNumber) {
         number++;
if (!isEvenNumber(number)) {
    oddcount++;
    continue;
}
         System.out.println("Even number " + number);
evencount++;
if (evencount >= 5) {
    break;
}
     }

        System.out.println("Total odd numbers found = " + oddcount);
        System.out.println("Total even numbers found = " + evencount);
    }

    public static boolean isEvenNumber(int number) {

        if ((number % 2) == 0) {
            return true;
        } else {
            return false;
        }
    }
}
