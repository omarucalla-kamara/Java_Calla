public class Sum3Challenge {

    public static void main(String[] args) {

        int countOfMatches = 0;
        int sumOfMatches = 0;

        for (int j = 1; j <= 1000; j++) {
            if ((j % 3 == 0) && (j % 5 == 0)) {
                countOfMatches++;
                sumOfMatches += j;
                System.out.println("Found a match = " + j);
            }

            if (countOfMatches == 5) {
                break;
            }
        }

        System.out.println("Sum = " + sumOfMatches);
    }
}