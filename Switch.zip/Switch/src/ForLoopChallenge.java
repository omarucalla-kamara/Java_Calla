public class ForLoopChallenge {
    public static void main(String[] args) {

        int count = 0;

        for (int i = 10; count < 3 && i <= 50; i++) {
            if (isPrime(i)) {
                System.out.println("number " + i + " is a prime number");
                count++;
            }
        }

    }

    public static boolean isPrime(int count) {

        if (count <= 2) {
            return (count == 2);
        }
        for (int divisor = 2; divisor < count; divisor++) {
            if (count % divisor == 0) {
                return false;
            }
        }
        return true;
    }
}
