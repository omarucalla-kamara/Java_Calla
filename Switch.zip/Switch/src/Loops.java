public class Loops {

    public int subNumber(int x, int y){
        return x - y;
    }

    public static void main(String[] args) {

        int num1 = 55;
        int num2 = 40;


        Loops obj = new Loops();
        Loops obj2 = new Loops();

        int output = obj.subNumber(num1, num2);
        System.out.println("The result is: " + output);


        int result = obj2.subNumber(22, 15);
        System.out.println("The result is: " + result);














//        int i = 5;
////        do {
////                System.out.println(i);
////                i+=2;
////
////        }while (i < 10);
//
//        while (i < 20) {
//            System.out.println(i);
//            i += 2;
//        }
    }
}
