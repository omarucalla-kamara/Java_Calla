public class SelfChallenge {
    public static void main(String[] args) {

        int HighScorePosition = calculateHighScorePostion(1500);
            displayHighScorePosition("Calla", HighScorePosition);
            HighScorePosition = calculateHighScorePostion(1000);
        displayHighScorePosition("Omar", HighScorePosition);
            HighScorePosition = calculateHighScorePostion(500);
        displayHighScorePosition("Kamara", HighScorePosition);
            HighScorePosition = calculateHighScorePostion(100);
        displayHighScorePosition("Omaru Calla", HighScorePosition);
            HighScorePosition = calculateHighScorePostion(25);
        displayHighScorePosition("Calla Kamara", HighScorePosition);
    }
public static void displayHighScorePosition(String playerName, int HighScorePosition) {
    System.out.println(playerName + " He Score a goal " + HighScorePosition + " Score so many goals");
}
    public static int calculateHighScorePostion(int playerScore) {
        if (playerScore >= 1000) {
            return 1;
        }
        else if (playerScore >= 500 && playerScore < 1000) {
            return 2;
        } else if (playerScore >= 100 && playerScore < 500) {
            return 3;
        } else {
            return 4;
        }
    }
}
