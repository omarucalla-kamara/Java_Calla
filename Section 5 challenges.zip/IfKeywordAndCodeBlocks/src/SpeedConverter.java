public class SpeedConverter {

    public static void main(String[] args) {
        toMilesPerHour(1.5);     // should print "1 km/h = 1 mi/h"
        toMilesPerHour(10.25);   // should print "10.25 km/h = 6 mi/h"
        toMilesPerHour(-5.6);    // should print "Invalid Value"
        toMilesPerHour(25.42);   // should print "25.42 km/h = 16 mi/h"
        toMilesPerHour(75.114);  // should print "75.114 km/h = 47 mi/h"
    }

    public static long toMilesPerHour(double kilometersPerHour) {
        if (kilometersPerHour < 0) {
            System.out.println("Invalid Value");
            return -1; // Invalid value
        }
        long milesPerHour = Math.round(kilometersPerHour / 1.60934);
        System.out.println(kilometersPerHour + " km/h = " + milesPerHour + " mi/h");
        return milesPerHour;}
}